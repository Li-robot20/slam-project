//

#ifndef STRUCTURESLAM_EDGELINEPRIORPROJECTXYZ_H
#define STRUCTURESLAM_EDGELINEPRIORPROJECTXYZ_H
#include <iostream>
#include "Thirdparty/g2o/g2o/core/base_unary_edge.h"
#include "Thirdparty/g2o/g2o/core/base_vertex.h"
#include <Eigen/Core>
#include"Converter.h"

#include <prior2D.h>

class EdgeLinePriorProjectXYZ: public g2o::BaseUnaryEdge <3,Eigen::Vector3d,g2o::VertexSBAPointXYZ>
{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    EdgeLinePriorProjectXYZ(prior2D p1, prior2D p2): BaseUnaryEdge(), _p1(p1), _p2(p2) {}

    //EdgeLinePriorProjectXYZ(prior2D _p1, prior2D _p2);

    void computeError()
    {
        const g2o::VertexSBAPointXYZ* v = static_cast<const g2o::VertexSBAPointXYZ*>(_vertices[0]);
        const Eigen::Vector3d xzy = v -> estimate();
        const double _p[2] = {xzy(0,0),xzy(2,0)};
        //_error = getError(_p, _p1, _p2);
        _error(0) = getError(_p, _p1, _p2)(0);
        _error(1) = getError(_p, _p1, _p2)(1);
        _error(2) = 0.0;


// 	std::cout <<"error:"<<_error(0,0)<<std::endl;
    }

    Eigen::Vector2d getError (const double p[2], const prior2D &l1, const prior2D &l2)
    {
        Eigen::Vector2d temp,p_;
        p_(0,0) = p[0];
        p_(1,0) = p[1];
        double cross = (l2.x-l1.x)*(p[0]-l1.x)+(l2.y-l1.y)*(p[1]-l1.y);
        if (cross <= 0)
            temp << l1.x,l1.y;

        double d2 = (l2.x-l1.x)*(l2.x-l1.x) + (l2.y-l1.y)*(l2.y-l1.y);
        if (cross >= d2)
            temp <<l2.x,l2.y;
        else{
            double r = cross /d2;
            double px =l1.x+(l2.x-l1.x)*r;
            double py =l1.y+(l2.y-l1.y)*r;
            temp << px, py;
        }
        return p_-temp;
    }

    //virtual bool read(istream& in){}
    //virtual bool write(ostream& out) const {}

    bool read(std::istream &is) {
        for (int i = 0; i < 3; i++) {
            is >> _measurement[i];
        }

        for (int i = 0; i < 3; ++i) {
            for (int j = i; j < 3; ++j) {
                is >> information()(i, j);
                if (i != j)
                    information()(j, i) = information()(i, j);
            }
        }
        return true;
    }

    bool write(std::ostream &os) const {
        for (int i = 0; i < 3; i++) {
            os << measurement()[i] << " ";
        }

        for (int i = 0; i < 3; ++i) {
            for (int j = i; j < 3; ++j) {
                os << " " << information()(i, j);
            }
        }
        return os.good();
    }

    prior2D _p1;
    prior2D _p2;

    Vector3d Xw;
    double fx, fy, cx, cy;
};


#endif //STRUCTURESLAM_EDGELINEPRIORPROJECTXYZ_H
