#ifndef PRIORLINE_H
#define PRIORLINE_H

struct priorline
{
  double x1;
  double y1;
  double x2;
  double y2;
  float distance;
};


#endif