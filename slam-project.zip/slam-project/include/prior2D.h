#ifndef PRIOR2D_H
#define PRIOR2D_H

struct prior2D
{
  double x;
  double y;
};

#endif