You should have received this g2o version along with ORB-SLAM2 (https://github.com/raulmur/ORB_SLAM2).
See the original g2o library at: https://github.com/RainerKuemmerle/g2o
All files included in this g2o version are BSD, see license-bsd.txt
